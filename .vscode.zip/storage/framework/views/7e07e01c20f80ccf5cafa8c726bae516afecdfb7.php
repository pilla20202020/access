<?php $__env->startSection('title', 'Add a New Credit'); ?>

<?php $__env->startSection('content'); ?>
    <section>
        <div class="section-body">
            <form class="form form-validate floating-label" action="<?php echo e(route('credit.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo $__env->make('credit.form',['header' => 'Add New Credit'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </form>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\customermanagement\resources\views/credit/create.blade.php ENDPATH**/ ?>