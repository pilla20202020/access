<!-- JAVASCRIPT -->
        
        <script src="<?php echo e(asset('js/jquery.min.js')); ?> "></script>


        
        <script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?> "></script>

        
        <script src="<?php echo e(asset('js/metisMenu.min.js')); ?> "></script>

        
        <script src="<?php echo e(asset('js/simplebar.min.js')); ?> "></script>


        
        

        
        

        <!-- Sweet alert init js-->
        <script src="<?php echo e(asset('js/sweetalert2.min.js')); ?>"></script>

        
        <script src="<?php echo e(asset('js/app.js')); ?>"></script>

        
        <script src="<?php echo e(asset('js/select2.min.js')); ?>"></script>

        <script src="<?php echo e(asset('js/scripts.js')); ?>"></script>

        <script src="<?php echo e(asset('js/toastr/toastr.js')); ?>"></script>

        <script src="<?php echo e(asset('js/jquery.repeater.min.js')); ?>"></script>

        <script src="<?php echo e(asset('js/form-repeater.init.js')); ?>"></script>

        

        <script>
            function deleteThis(obj) {
                let data= obj.getAttribute("link");
                Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                if (result.isConfirmed) {
                    window.location = data;
                    Swal.fire(
                    'Deleted!',
                    'Your file has been deleted.',
                    'success'
                    )
                } else {
                    Swal.fire(
                    'Cancelled!',
                    'Your file has been Cancelled.',
                    'error'
                    )
                }
                })
            }
        </script>

        <?php echo $__env->yieldContent('page-specific-scripts'); ?>
        <?php echo Toastr::message(); ?>




    </body>
</html>
<?php /**PATH C:\xampp\htdocs\newprojectwithroleandpermission\resources\views/layouts/admin/scripts.blade.php ENDPATH**/ ?>