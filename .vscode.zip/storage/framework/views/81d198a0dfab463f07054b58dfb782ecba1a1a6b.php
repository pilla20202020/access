<?php $__env->startSection('title', 'Create a role'); ?>

<?php $__env->startSection('content'); ?>
    <section>
        <div class="section-body">
            <form class="form form-validate floating-label" action="<?php echo e(route('role.store')); ?>" method="POST" enctype="multipart/form-data" novalidate>
            <?php echo $__env->make('role.form',['header' => 'Create a role'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </form>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bibhuti - access\resources\views/role/create.blade.php ENDPATH**/ ?>