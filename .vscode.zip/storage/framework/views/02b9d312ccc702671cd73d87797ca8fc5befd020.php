<!doctype html>
<html lang="en">

    <head>
        <meta charset="utf-8" />
        <title><?php echo $__env->yieldContent('title'); ?></title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
        <meta content="Themesbrand" name="author" />

        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <!-- App favicon -->
        <link rel="shortcut icon" href="assets/images/favicon.ico">

        
        <link href="<?php echo e(asset('css/MetroJs.min.css')); ?>" id="app-style" rel="stylesheet" type="text/css" />

        <!-- Bootstrap Css -->
        
        <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" id="app-style" rel="stylesheet" type="text/css" />

        <!-- Icons Css -->
        
        <link href="<?php echo e(asset('css/icons.min.css')); ?>" id="app-style" rel="stylesheet" type="text/css" />

        <!-- App Css-->
        
        <link href="<?php echo e(asset('css/app.min.css')); ?>" id="app-style" rel="stylesheet" type="text/css" />

        <!-- Sweet Alert-->
        <link href="<?php echo e(asset('css/sweetalert2.min.css')); ?>" rel="stylesheet" type="text/css" />

        <!-- Select2-->
        <link href="<?php echo e(asset('css/select2.min.css')); ?>" rel="stylesheet" />

        <!-- style-->
        <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet" />

        <link href="<?php echo e(asset('css/dropify.min.css')); ?>" rel="styleshet">

        <!-- Toastr-->
        <link rel="stylesheet" href="<?php echo e(asset('css/toastr.min.css')); ?>">

        <?php echo $__env->yieldContent('page-specific-styles'); ?>

    </head>
<?php /**PATH C:\xampp\htdocs\newprojectwithroleandpermission\resources\views/layouts/admin/head.blade.php ENDPATH**/ ?>