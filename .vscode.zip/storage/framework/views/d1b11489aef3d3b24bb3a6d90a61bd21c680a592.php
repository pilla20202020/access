<?php $__env->startSection('page-specific-styles'); ?>
    <link href="<?php echo e(asset('css/dropify.min.css')); ?>" rel="stylesheet">
    <link type="text/css" rel="stylesheet"
          href="<?php echo e(asset('resources/css/theme-default/libs/bootstrap-tagsinput/bootstrap-tagsinput.css?1424887862')); ?>"/>
<?php $__env->stopSection(); ?>
<?php echo csrf_field(); ?>
<div class="row">
    <div class="col-sm-9">
        <div class="card">
            <div class="card-underline">
                <div class="card-head">
                    <header class="ml-3 mt-2"><?php echo $header; ?></header>
                </div>
                <div class="card-body">

                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group ">
                                <label for="name" class="col-form-label pt-0">Title</label>
                                <input class="form-control" type="text" required name="title" value="<?php echo e(old('title', isset($roomtype->title) ? $roomtype->title : '')); ?>" placeholder="Enter Room Title">
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <div class="form-group ">
                                <label for="name" class="col-form-label pt-0">Price</label>
                                <input type="number" name="price" class="form-control"  value="<?php echo e(old('price', isset($roomtype->price) ? $roomtype->price : '')); ?>"/>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card" >
            <div class="card-body">
                <div class="row mt-2 justify-content-center">
                    <div class="form-group">
                        <div>
                            <a class="btn btn-light waves-effect ml-1" href="<?php echo e(route('room.index')); ?>">
                                <i class="md md-arrow-back"></i>
                                Back
                            </a>
                            <input type="submit" name="pageSubmit" class="btn btn-danger waves-effect waves-light" value="Submit">
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>


<?php $__env->startSection('page-specific-scripts'); ?>
    <script src="<?php echo e(asset('resources/js/libs/bootstrap-tagsinput/bootstrap-tagsinput.min.js')); ?>"></script>
    <script src="<?php echo e(asset('resources/js/libs/jquery-validation/dist/jquery.validate.min.js')); ?>"></script>
    <script src="<?php echo e(asset('resources/js/libs/jquery-validation/dist/additional-methods.min.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php /**PATH /home/demoaccessworld/public_html/projects/customermanagement/resources/views/roomtype/form.blade.php ENDPATH**/ ?>