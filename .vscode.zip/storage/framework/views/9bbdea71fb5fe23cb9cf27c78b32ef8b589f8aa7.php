<?php $__env->startSection('page-specific-styles'); ?>
    <link href="<?php echo e(asset('css/dropify.min.css')); ?>" rel="stylesheet">
    <link type="text/css" rel="stylesheet"
        href="<?php echo e(asset('resources/css/theme-default/libs/bootstrap-tagsinput/bootstrap-tagsinput.css?1424887862')); ?>" />
<?php $__env->stopSection(); ?>
<?php echo csrf_field(); ?>
<div class="row">
    <div class="col-sm-9">
        <div class="card">
            <div class="card-underline">
                <div class="card-head">
                    <header class="ml-3 mt-2"><?php echo $header; ?></header>
                </div>
                <div class="card-body">

                    <div class="row">

                        <div class="col-sm-12">
                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div><br />
                            <?php endif; ?>
                            <div class="form-group ">
                                <label for="name" class="col-form-label pt-0">Test Preparation Name</label>
                                <div class="">
                                    <input class="form-control" type="text" required name="name"
                                        value="<?php echo e(old('name', isset($preparation->name) ? $preparation->name : '')); ?>"
                                        placeholder="Enter Test Preparation Name">
                                </div>
                            </div>
                            

                            
                            <div class="form-group">
                                <label for="comment">Description:</label>
                                <textarea class="form-control" rows="5" id="description" name="description">
                                    <?php if(isset($preparation)): ?>
                                        <?php echo e($preparation->description); ?>

                                    <?php endif; ?>
                                </textarea>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card">
            <div class="card-body">
                <div class="row mt-2 justify-content-center">
                    <div class="form-group">
                        <div>
                            <a class="btn btn-light waves-effect ml-1" href="<?php echo e(route('preparation.index')); ?>">
                                <i class="md md-arrow-back"></i>
                                Back
                            </a>
                            <input type="submit" class="btn btn-danger waves-effect waves-light" value="Submit">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->startSection('page-specific-scripts'); ?>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\xampp\htdocs\bibhuti - access\resources\views/preparation/form.blade.php ENDPATH**/ ?>