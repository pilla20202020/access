<div class="vertical-menu">

    <div data-simplebar class="h-100">

        <!--- Sidemenu -->
        <div id="sidebar-menu">
            <!-- Left Menu Start -->
            <ul class="metismenu list-unstyled" id="side-menu">
                <li class="menu-title">Main</li>

                <li>
                               <a href="<?php echo e(route('dashboard')); ?>" class="waves-effect">
                        <i class="mdi mdi-speedometer"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                <?php if(auth()->check() && auth()->user()->hasRole('SuperAdmin')): ?>
                    <li>
                        <a href="javascript: void(0);" class="has-arrow" aria-expanded="false">
                            <i class="mdi mdi-share-variant"></i>
                            <span>Admin</span>
                        </a>
                        <ul class="sub-menu mm-collapse" aria-expanded="true">
                            <li><a href="<?php echo e(route('user.index')); ?>" aria-expanded="false"><i class="fas fa-user"></i></i>
                                    Users</a></li>
                            <li><a href="<?php echo e(route('role.index')); ?>" aria-expanded="false"><i class="fa fa-tasks"></i>
                                    Roles</a></li>
                            <li><a href="<?php echo e(route('permission.index')); ?>" aria-expanded="false"><i class="fa fa-lock"></i>
                                    Permissions</a></li>
                            <li><a href="<?php echo e(route('qualification.index')); ?>" aria-expanded="false"><i
                                        class="fas fa-graduation-cap"></i> Qualification</a></li>
                            <li><a href="<?php echo e(route('preparation.index')); ?>" aria-expanded="false"><i
                                        class="fas fa-tasks"></i> Preparation</a></li>
                            <li><a href="<?php echo e(route('leadcategory.index')); ?>" aria-expanded="false"><i
                                        class="fas fa-list-alt"></i> Lead Category</a></li>
                            <li><a href="<?php echo e(route('location.index')); ?>" aria-expanded="false"><i
                                        class="fa fa-map-marker"></i> Location</a></li>
                        </ul>
                    </li>
                <?php endif; ?>

                <li class="">
                    <a href="javascript: void(0);" class="has-arrow waves-effect" aria-expanded="false">
                        <i class="mdi mdi-share-variant"></i>
                        <span>Registration</span>
                    </a>
                    <ul class="sub-menu mm-collapse" aria-expanded="true">

                        <?php if(auth()->check() && auth()->user()->hasRole('SuperAdmin')): ?>
                            <li class=""><a href="javascript: void(0);" class="has-arrow" aria-expanded="false"><i
                                        class="fas fa-hand-point-right"></i>Campaign</a>

                                <?php if(getCampaign()->count() > 0): ?>
                                    <?php $__currentLoopData = getCampaign(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $campaign): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <ul class="sub-menu mm-collapse" aria-expanded="true" style="height: 0px;">
                                            <li class=""><a href="javascript: void(0);" class="has-arrow"
                                                    aria-expanded="false"><i
                                                        class="fas fa-hand-point-right"></i><?php echo e($campaign->name); ?></a>
                                                <?php if($campaign->registrations->isEmpty() == false): ?>
                                                    <?php $__currentLoopData = $campaign->registrations->unique('leadcategory_id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registration): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <ul class="sub-menu mm-collapse" aria-expanded="true"
                                                            style="height: 0px;">
                                                            <li><a
                                                                    href="<?php echo e(route('registration.getregistration_by_campaign_and_leadcategory', ['campaign_id' => $campaign->id, 'leadcategory_id' => $registration->leadcategory_id])); ?>"><i
                                                                        class="fas fa-hand-point-right"></i><?php echo e($registration->leadcategory->name); ?></a>
                                                            </li>
                                                        </ul>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </li>
                                        </ul>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </li>

                            <li class=""><a href="javascript: void(0);" class="has-arrow" aria-expanded="false"><i
                                        class="fas fa-hand-point-right"></i>Location</a>
                                <?php if(getLocation()->count() > 0): ?>
                                    <?php $__currentLoopData = getLocation(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <ul class="sub-menu mm-collapse" aria-expanded="true" style="height: 0px;">
                                            <li class=""><a href="javascript: void(0);" class="has-arrow"
                                                    aria-expanded="false"><i
                                                        class="fas fa-hand-point-right"></i><?php echo e($location->name); ?></a>
                                                <?php if($location->registrations->isEmpty() == false): ?>
                                                    <?php $__currentLoopData = $location->registrations->unique('leadcategory_id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registration): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <ul class="sub-menu mm-collapse" aria-expanded="true"
                                                            style="height: 0px;">
                                                            <li><a
                                                                    href="<?php echo e(route('registration.getregistration_by_location_and_leadcategory', ['location_slug' => $registration->preffered_location, 'leadcategory_id' => $registration->leadcategory_id])); ?>"><i
                                                                        class="fas fa-hand-point-right"></i><?php echo e($registration->leadcategory->name); ?></a>
                                                            </li>
                                                        </ul>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </li>
                                        </ul>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </li>
                        <?php endif; ?>

                        <?php if(auth()->check() && auth()->user()->hasRole('SuperAdmin|Consultancy')): ?>
                            <li class=""><a href="<?php echo e(route('registration.index')); ?>"><i
                                        class="fas fa-hand-point-right"></i>View All</a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </li>


                <?php if(auth()->check() && auth()->user()->hasRole('SuperAdmin')): ?>
                    <li>
                        <a href="<?php echo e(route('campaign.index')); ?>" class="waves-effect">
                            <i class="mdi mdi-trophy"></i>
                            <span>Campaign</span>
                        </a>
                    </li>

                    <li>
                        <a href="<?php echo e(route('followup.index')); ?>" class="waves-effect">
                            <i class="fa fa-bookmark"></i>
                            <span>Follow Up</span>
                        </a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\bibhuti - access\resources\views/layouts/admin/sidebar.blade.php ENDPATH**/ ?>