<?php $__env->startSection('page-specific-styles'); ?>
    <link href="<?php echo e(asset('css/dropify.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title', 'Setting'); ?>

<?php $__env->startSection('content'); ?>
    <section>
        <?php echo e(Form::open(['route'=>'setting.update','class'=>'form form-validate','method'=>'PUT','files'=>true,'novalidate'])); ?>

        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-head d-flex p-2">
                        <header>General Settings</header>
                        <div class="tools ml-auto">
                            <input type="submit" class="btn btn-primary" value="Save All">
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-4">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="card">
                                <div class="card-head">
                                    <header class="p-2">General</header>
                                </div>
                                <div class="card-body tab-content">
                                    <div class="tab-pane active" id="first2">

                                        <div class="form-group">
                                            <?php echo e(Form::label('setting[project_name]', 'Project Title')); ?>

                                            <?php echo e(Form::text('setting[project_name]', old('setting.project_name') ?: setting('project_name'), ['class'=>'form-control'])); ?>

                                        </div>
                                        <div class="form-group">
                                            <?php echo e(Form::label('setting[description]', 'Site description')); ?>

                                            <?php echo e(Form::text('setting[description]', old('setting.description') ?: setting('description'), ['class'=>'form-control'])); ?>

                                        </div>
                                        <div class="form-group">
                                            <?php echo e(Form::label('setting[address]', 'Address')); ?>

                                            <?php echo e(Form::textarea('setting[address]', old('setting.address') ?: setting('address'), ['class'=>'form-control','rows'=>2,])); ?>

                                        </div>
                                        <div class="form-group">
                                            <?php echo e(Form::label('setting[google_map]', 'Google Map Link')); ?>

                                            <?php echo e(Form::textarea('setting[google_map]', old('setting.google_map') ?: setting('google_map'), ['class'=>'form-control','rows'=>2])); ?>

                                        </div>


                                        <?php if(setting('image')): ?>
                                            <img id="holder" style="margin-top:15px;max-height:300px;" class="img img-fluid" src="<?php echo e(setting('image')); ?>">
                                        <?php endif; ?>
                                        <input id="thumbnail" class="form-control" type="text" name="setting[image]" readonly>
                                        <button id="lfm" data-input="thumbnail" data-preview="holder" class="btn btn-icon icon-left btn-primary mt-2">
                                            <i class="fa fa-upload"></i> &nbsp;Choose
                                        </button>




                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="card">
                                <div class="card-head">
                                    <header class="p-2">SMS</header>
                                </div>
                                <div class="card-body tab-content">
                                    <div class="tab-pane active" id="first3">
                                        <div class="form-group">
                                            <?php echo e(Form::label('setting[sms_api]', 'SMS API')); ?>

                                            <?php echo e(Form::text('setting[sms_api]', old('setting.sms_api') ?: setting('sms_api'), ['class'=>'form-control'])); ?>

                                        </div>
                                        <div class="form-group">
                                            <?php echo e(Form::label('setting[sms_token]', 'SMS TOKEN')); ?>

                                            <?php echo e(Form::text('setting[sms_token]', old('setting.sms_token') ?: setting('sms_token'), ['class'=>'form-control'])); ?>

                                        </div>

                                        <div class="form-group">
                                            <?php echo e(Form::label('setting[sms_from]', 'SMS From')); ?>

                                            <?php echo e(Form::text('setting[sms_from]', old('setting.sms_from') ?: setting('sms_from'), ['class'=>'form-control'])); ?>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="card">
                                <div class="card-head">
                                    <header class="p-2">Social Links</header>
                                </div>
                                <div class="card-body">
                                    <div class="form-group">
                                        <?php echo e(Form::label('setting[facebook]', 'Facebook')); ?>

                                        <?php echo e(Form::textarea('setting[facebook]', old('setting.facebook') ?: setting('facebook'), ['class'=>'form-control','rows'=>2])); ?>

                                    </div>
                                    <div class="form-group">
                                        <?php echo e(Form::label('setting[instagram]', 'Instagram')); ?>

                                        <?php echo e(Form::textarea('setting[instagram]', old('setting.instagram') ?: setting('instagram'), ['class'=>'form-control','rows'=>2])); ?>

                                    </div>
                                    <div class="form-group">
                                        <?php echo e(Form::label('setting[twitter]', 'Twitter')); ?>

                                        <?php echo e(Form::textarea('setting[twitter]', old('setting.twitter') ?: setting('twitter'), ['class'=>'form-control','rows'=>2])); ?>

                                    </div>
                                    <div class="form-group">
                                        <?php echo e(Form::label('setting[youtube]', 'Youtube')); ?>

                                        <?php echo e(Form::textarea('setting[youtube]', old('setting.youtube') ?: setting('youtube'), ['class'=>'form-control','rows'=>2])); ?>

                                    </div>
                                    <div class="form-group">
                                        <?php echo e(Form::label('setting[linkedin]', 'LinkedIn')); ?>

                                        <?php echo e(Form::textarea('setting[linkedin]', old('setting.linkedin') ?: setting('linkedin'), ['class'=>'form-control','rows'=>2])); ?>

                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            

        </div>
        </div>
        <?php echo e(Form::close()); ?>

    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-specific-scripts'); ?>

    <script src="<?php echo e(asset('js/dropify.min.js')); ?>"></script>
    <script src="/vendor/laravel-filemanager/js/stand-alone-button.js"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            $('.dropify').dropify();
        });

        $('#lfm').filemanager('image');

    </script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bibhuti - access\resources\views/setting/index.blade.php ENDPATH**/ ?>