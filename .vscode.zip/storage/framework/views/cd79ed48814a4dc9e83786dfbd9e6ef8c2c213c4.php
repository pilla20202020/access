<?php $__env->startSection('page-specific-styles'); ?>
    <link href="<?php echo e(asset('css/dropify.min.css')); ?>" rel="stylesheet">
    <link type="text/css" rel="stylesheet"
          href="<?php echo e(asset('resources/css/theme-default/libs/bootstrap-tagsinput/bootstrap-tagsinput.css?1424887862')); ?>"/>
<?php $__env->stopSection(); ?>
<?php echo csrf_field(); ?>
<div class="row">
    <div class="col-sm-9">
        <div class="card">
            <div class="card-underline">
                <div class="card-head">
                    <header class="ml-3 mt-2"><?php echo $header; ?></header>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-sm-12">
                            

                            <div class="form-group ">
                                <label for="name" class="col-form-label pt-0">Permission</label>
                                <div class="">
                                    <input class="form-control" type="text" required name="name" value="<?php echo e(old('name', isset($permission->name) ? $permission->name : '')); ?>" placeholder="Enter Your Name">
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label for="group" class="col-form-label pt-0">Permission Group</label>
                                <div class="">
                                    <input type="text" class="form-control" name="group_name" value="<?php echo e(old('group_name', isset($permission->group_name) ? $permission->group_name: '')); ?>" placeholder="Names: Employee,Staff,Candidate etc">
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card" >
            <div class="card-body">
                <div class="row mt-2 justify-content-center">
                    <div class="form-group">
                        <div>
                            <a class="btn btn-light waves-effect ml-1" href="<?php echo e(route('permission.index')); ?>">
                                <i class="md md-arrow-back"></i>
                                Back
                            </a>
                            <input type="submit" name="pageSubmit" class="btn btn-danger waves-effect waves-light" value="Submit">
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>


<?php $__env->startSection('page-specific-scripts'); ?>
    <script src="<?php echo e(asset('resources/js/ckeditor/ckeditor.js')); ?>"></script>
    <script src="<?php echo e(asset('js/dropify.min.js')); ?>"></script>
    <script src="<?php echo e(asset('resources/js/libs/bootstrap-tagsinput/bootstrap-tagsinput.min.js')); ?>"></script>
    <script src="<?php echo e(asset('resources/js/libs/jquery-validation/dist/jquery.validate.min.js')); ?>"></script>
    <script src="<?php echo e(asset('resources/js/libs/jquery-validation/dist/additional-methods.min.js')); ?>"></script>
    <script type="text/javascript">
        $(document).ready(function () {
            $('.dropify').dropify();
        });
    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\xampp\htdocs\newprojectwithroleandpermission\resources\views/permission/form.blade.php ENDPATH**/ ?>