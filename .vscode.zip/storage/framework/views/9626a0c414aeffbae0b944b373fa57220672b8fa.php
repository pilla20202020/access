<?php if(!empty($editRoute)): ?>
    <a href="<?php echo e($editRoute); ?>"><button type="button" class="btn btn-icon-toggle btn-sm" data-toggle="tooltip" data-placement="top" data-original-title="Edit"><i class="mdi mdi-pencil"></i></button></a>
<?php endif; ?>

<?php if(!empty($printRoute)): ?>
    <a href="<?php echo e($printRoute); ?>" target="_blank"><button type="button" class="btn btn-icon-toggle btn-sm" data-toggle="tooltip" data-placement="top" data-original-title="Print"><i class="mdi mdi-printer"></i></button></a>
<?php endif; ?>

<?php if(!empty($viewRoute)): ?>
    <a href="<?php echo e($viewRoute); ?>" target="__blank"><button type="button" class="btn btn-icon-toggle btn-sm" data-toggle="tooltip"  data-placement="top" data-original-title="View"><i class="far fa-eye"></i></button></a>
<?php endif; ?>

<?php if(!empty($resumeRoute)): ?>
    <a href="<?php echo e($resumeRoute); ?>"><button type="button" class="btn btn-icon-toggle btn-sm" data-toggle="tooltip"  data-placement="top" data-original-title="View Resume"><i class="fa fa-file"></i></button></a>
<?php endif; ?>

<?php if(!empty($showRoute)): ?>
    <a href="<?php echo e($showRoute); ?>" ><button type="button" class="btn btn-icon-toggle" data-toggle="tooltip" data-placement="top" data-original-title="Show"><i class="far fa-eye"></i></button></a>
<?php endif; ?>

<?php if(!empty($deleteRoute)): ?>
    
        <button type="button" class="btn btn-icon-toggle" onclick="deleteThis(this); return false;" link="<?php echo e($deleteRoute); ?>">
            <i class="far fa-trash-alt"></i>
        </button>
    
<?php endif; ?>

<?php if(!empty($checklist)): ?>
    <button type="button" class="btn btn-primary btn-approve btn-sm mb-1" onclick="approvedthis(<?php echo e($checklist); ?>)" value="1">Add Check Out</button>
<?php endif; ?>

<?php if(!empty($billRoute)): ?>
    <a href="<?php echo e($billRoute); ?>" ><button type="button" class="btn btn-warning btn-reject btn-sm" data-toggle="tooltip" data-placement="top" data-original-title="Generate Bill">Add Bill</button></a>
<?php endif; ?>

<?php if(!empty($invoiceRoute)): ?>
    <a href="<?php echo e($invoiceRoute); ?>" ><button type="button" class="btn btn-danger btn-reject btn-sm" data-toggle="tooltip" data-placement="top" data-original-title="Generate Bill">Generate Invoice</button></a>
<?php endif; ?>




<?php /**PATH C:\xampp\htdocs\customermanagement\resources\views/general/table-actions.blade.php ENDPATH**/ ?>