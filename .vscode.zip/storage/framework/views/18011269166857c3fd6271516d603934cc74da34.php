<?php $__env->startSection('title', 'Add a New Customer'); ?>

<?php $__env->startSection('content'); ?>
    <section>
        <div class="section-body">
            <form class="form form-validate floating-label" action="<?php echo e(route('customer.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo $__env->make('customer.form',['header' => 'Add new Customer'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </form>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
 <script>
    $(document).ready(function(){

        $('#perm_province_id_dropdown').on('change', function(e){
            e.preventDefault();
            var province_id = $(this).val();
            $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
            $.ajax({
                type: "POST",
                url: "<?php echo e(route('customer.get_perm_district')); ?>",
                data:{
                    perm_province_id:province_id
                },
                dataType: "json",
                success: function(response){
                    // console.log(response.message);
                    $('#perm_district_id_dropdown').html('<option value="" selected disabled>Select District</option>');
                    $.each(response.message, function(key, value){
                        $('#perm_district_id_dropdown').append('<option value="'+value.id+'">'+value.district_name+'</option>')
                    });
                }
            })
        });

        $('#perm_district_id_dropdown').on('change', function(e){
            e.preventDefault();
            var district_id = $(this).val();
            $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
            $.ajax({
                type: "POST",
                url: "<?php echo e(route('customer.get_perm_municipality')); ?>",
                data:{
                    perm_district_id:district_id
                },
                dataType: "json",
                success: function(response){
                    // console.log(response.message);
                    $('#perm_municipality_id_dropdown').html('<option value="" selected disabled>Select District</option>');
                    $.each(response.message, function(key, value){
                        $('#perm_municipality_id_dropdown').append('<option value="'+value.id+'">'+value.name+'</option>')
                    });
                }
            })
        });

        $('#marital_status').on('change', function(){
            var status = $(this).val();
            if(status == 'Married')
            {
                $('.spouse-name').show();
            } else {
                $('.spouse-name').hide();
            }
        });



    });


 </script>

 <script src="<?php echo e(asset('js/employee/perm_address.js')); ?>"></script>
 <script src="<?php echo e(asset('js/employee/temp_address.js')); ?>"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\customermanagement\resources\views/customer/create.blade.php ENDPATH**/ ?>