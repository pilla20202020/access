<?php $__env->startSection('page-specific-styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/jquery.dataTables.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/TableTools.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/lightbox.css')); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'Followups'); ?>


<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="d-flex">
                <header class="text-capitalize pt-1">Followup Lists</header>
            </div>
            <div class="card mt-2 p-4">
                <div class="table-responsive">

                    <table id="datatable" class="table table-bordered">
                        <thead>
                            <tr>
                                <th>SN</th>
                                <th>Student Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Next Schedule</th>
                                <th>Follow Up By</th>
                                <th>Remarks</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php echo $__env->renderEach('followup.partials.table', $followups, 'followup'); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-specific-scripts'); ?>
    <script src="<?php echo e(asset('js/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/lightbox.js')); ?>"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            $('#datatable').DataTable();
        });

        $(document).on('click','.addfollowup',function (e) {
            let commission_id = $(this).data('commission_id');
            $(".change_claim_commission").val(commission_id);
            $('.add_followup').modal('show');

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bibhuti - access\resources\views/followup/index.blade.php ENDPATH**/ ?>