<tr>
    <td><?php echo e(++$key); ?></td>
    <td><?php echo e(Str::limit($campaign->name, 47)); ?></td>
    <td>
        <img src="<?php echo e(asset($campaign->thumbnail_path)); ?>" class="img-circle width-1" alt="<?php echo e($campaign->name); ?>" width="50" height="50">
    </td>
    <td><?php echo e(Str::limit($campaign->details, 47)); ?></td>
    <td><?php echo e(Str::limit($campaign->starts, 47)); ?></td>
    <td><?php echo e(Str::limit($campaign->ends, 47)); ?></td>

    <td>
        <a href="<?php echo e(route('campaign.edit', $campaign->id)); ?>">
            <button type="button" class="btn btn-icon-toggle btn-sm" data-toggle="tooltip" data-placement="top" data-original-title="Edit"><i class="mdi mdi-pencil"></i></button>
        </a>
        <a href="#">
            <button type="button" class="btn btn-icon-toggle" onclick="deleteThis(this); return false;" link="<?php echo e(route('campaign.destroy', $campaign->id)); ?>">
                <i class="far fa-trash-alt"></i>
            </button>
        </a>
    </td>
</tr>


<?php /**PATH C:\xampp\htdocs\bibhuti - access\resources\views/campaign/partials/table.blade.php ENDPATH**/ ?>