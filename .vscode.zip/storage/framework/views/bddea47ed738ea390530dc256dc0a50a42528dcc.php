
<?php $__env->startSection('title', 'New Project'); ?>


<?php $__env->startSection('page-specific-styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/jquery.dataTables.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/TableTools.min.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset('css/lightbox.css')); ?>"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
            <!-- start page title -->
                <div class="row">
                    <div class="col-12">
                        <div class="page-title-box d-flex align-items-center justify-content-between">
                            <h4 class="mb-0 font-size-18">Dashboard</h4>

                            <div class="page-title-right">
                                <ol class="breadcrumb m-0">
                                    <li class="breadcrumb-item"><a href="javascript: void(0);">New Project</a></li>
                                    <li class="breadcrumb-item active">Dashboard</li>
                                </ol>
                            </div>

                        </div>
                    </div>
                </div>
                <!-- end page title -->

                
                <div class="col-xl-12 p-0">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title mb-4">Campaign Lists</h5>
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="table-responsive">
                                        <table id="example" class="table table-hover display example">
                                            <thead>
                                                <tr>
                                                    <th>S.N.</th>
                                                    <th>Name</th>
                                                    <th>Detail</th>
                                                    <th>Starts</th>
                                                    <th>Ends</th>
                                                    <th>Total Enquiry</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $campaigns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $campaign): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e(++$key); ?></td>
                                                    <td><?php echo e(Str::limit($campaign->name, 47)); ?></td>
                                                    <td><?php echo e(Str::limit($campaign->details, 47)); ?></td>
                                                    <td><?php echo e(Str::limit($campaign->starts, 47)); ?></td>
                                                    <td><?php echo e(Str::limit($campaign->ends, 47)); ?></td>
                                                    <td><?php echo e($campaign->registrations->count()); ?></td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <!--end table-responsive-->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                

                
                <div class="col-xl-12 p-0">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title mb-4">Recent Enquiry Lists</h5>
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="table-responsive">
                                        <table id="example" class="table table-hover display example">
                                            <thead>
                                                <tr>
                                                    <th>S.N.</th>
                                                    <th>Name</th>
                                                    <th>Email</th>
                                                    <th>Phone</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $registrations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $registration): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e(++$key); ?></td>
                                                    <td><?php echo e(Str::limit($registration->name, 47)); ?></td>
                                                    <td><?php echo e(Str::limit($registration->email, 47)); ?></td>
                                                    <td><?php echo e(Str::limit($registration->phone, 47)); ?></td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <!--end table-responsive-->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                




                
                <div class="col-xl-12 p-0">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title mb-4">Upcoming Follow Up Lists</h5>
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="table-responsive">
                                        <table id="example" class="table table-hover display example">
                                            <thead>
                                                <tr>
                                                    <th>Student Name</th>
                                                    <th>Email</th>
                                                    <th>Phone</th>
                                                    <th>Follow Up By</th>
                                                    <th>Follow Up Dates</th>
                                                    <th>Remarks</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $followups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $followup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if(($followup->follow_up_type == "registration") && !empty($followup->registration($followup->id))): ?>
                                                        <tr>
                                                            <td>
                                                                <?php echo e($followup->registration($followup->id)->name); ?>

                                                            </td>
                                                            <td>
                                                                <?php echo e($followup->registration($followup->id)->email); ?>

                                                            </td>

                                                            <td>
                                                                <?php echo e($followup->registration($followup->id)->phone); ?>

                                                            </td>
                                                            <td>
                                                                <?php echo e($followup->follow_up_by); ?>

                                                            </td>
                                                            <td><?php echo e($followup->next_schedule); ?></td>
                                                            <td><?php echo e($followup->remarks); ?></td>
                                                        </tr>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <!--end table-responsive-->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                





        <!-- End Page-content -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-specific-scripts'); ?>
    <script src="<?php echo e(asset('js/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/lightbox.js')); ?>"></script>
    <script>
        $(document).ready( function () {
            $('.example').DataTable();
        } );
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bibhuti - access\resources\views/dashboard/index.blade.php ENDPATH**/ ?>