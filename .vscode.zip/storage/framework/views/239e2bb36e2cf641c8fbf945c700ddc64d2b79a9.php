<?php $__env->startSection('title', 'Create a Lead Category'); ?>

<?php $__env->startSection('content'); ?>
    <section>
        <div class="section-body">
            <form class="form form-validate floating-label" action="<?php echo e(route('leadcategory.store')); ?>" method="POST" novalidate>
            <?php echo $__env->make('leadcategory.form',['header' => 'Create a Lead Category'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </form>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bibhuti - access\resources\views/leadcategory/create.blade.php ENDPATH**/ ?>