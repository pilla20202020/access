

<?php $__env->startSection('page-specific-styles'); ?>
    <link href="<?php echo e(asset('css/dropify.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('resources/css/bootstrap-toggle.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title',$qualification->name); ?>

<?php $__env->startSection('content'); ?>
    <section>
        <div class="section-body">
            <form class="form form-validate floating-label" action="<?php echo e(route('qualification.update',$qualification->id)); ?>"
                  method="POST" enctype="multipart/form-data" novalidate>
            <?php echo method_field('PUT'); ?>
            <?php echo $__env->make('qualification.form', ['header' => 'Edit qualification <span class="text-primary">('.($qualification->job_type).')</span>'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </form>
        </div>
    </section>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-specific-scripts'); ?>
    <script src="<?php echo e(asset('js/dropify.min.js')); ?>"></script>
    <script src="<?php echo e(asset('resources/js/bootstrap-toggle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('resources/js/libs/jquery-validation/dist/additional-methods.min.js')); ?>"></script>
    <script src="<?php echo e(asset('resources/js/libs/jquery-validation/dist/jquery.validate.min.js')); ?>"></script>
    <script type="text/javascript">
        $(document).ready(function () {
            $('.dropify').dropify();
        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bibhuti - access\resources\views/qualification/edit.blade.php ENDPATH**/ ?>