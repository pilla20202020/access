<?php $__env->startSection('page-specific-styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/jquery.dataTables.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/TableTools.min.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset('css/lightbox.css')); ?>"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'CheckIn List'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="d-flex">
                <header class="text-capitalize pt-1">CheckIn List</header>
                <div class="tools ml-auto">
                    <a class="btn btn-primary ink-reaction" href="<?php echo e(route('checkin.create')); ?>">
                        <i class="md md-add"></i>
                        Add CheckIn
                    </a>
                </div>
            </div>
            <div class="card mt-2 p-4">
                <div class="table-responsive">

                    <table id="datatable" class="table table-bordered">
                        <thead>
                        <tr>
                            <th>ID</th>
                            <th>S.No.</th>
                            <th>Customers</th>
                            <th>Checked In</th>
                            <th>Checked Out</th>
                            <th>Total No. of Rooms</th>
                            <th>Room No.</th>
                            <th>Room Type</th>
                            <th>Total No. of People</th>
                            <th>Initial Payment</th>
                            <th>Actions</th>
                        </tr>
                        </thead>
                        <tbody></tbody>
                        <tfoot>
                        <tr>
                            <th>ID</th>
                            <th>S.No.</th>
                            <th>Customers</th>
                            <th>Checked In</th>
                            <th>Checked Out</th>
                            <th>Total No. of Rooms</th>
                            <th>Room No.</th>
                            <th>Room Type</th>
                            <th>Total Number of People</th>
                            <th>Initial Payment</th>
                        </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade bs-example-modal-center" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-mb">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title align-self-center mt-0 text-center" id="exampleModalLabel">User Leave History</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('checkin.add_checkout')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="card">
                                    <div class="card-underline">

                                        <div class="card-body">
                                            <div class="row">
                                                <div class="col-sm-6">
                                                    <input type="hidden" class="checkin_id" name="checkin_id">
                                                    <div class="form-group">
                                                        <label for="checked_out" class="col-form-label pt-0">Checked Out Date</label>
                                                        <input type="date" class="form-control" name="checked_out" min="<?php echo e(date('Y-m-d')); ?>" required value="">
                                                        <?php $__errorArgs = ['checked_out'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="text-danger"><?php echo e($errors->first('checked_out')); ?></span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                            </div>


                                            <hr>
                                            <div class="row mt-2 justify-content-center">
                                                <div class="form-group">
                                                    <div>
                                                        <input type="submit" name="pageSubmit" class="btn btn-danger waves-effect waves-light" value="Submit">
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-specific-scripts'); ?>
    <script src="<?php echo e(asset('js/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/lightbox.js')); ?>"></script>
    <script>
        $(document).ready( function () {
            $('#datatable tfoot th').each(function() {
                var title = $(this).text();
                $(this).html('<input type="text" style="width: 100%;" placeholder="Search ' + title + '" />');
            });
            var table = $('#datatable').DataTable({
                "processing": true,
                "serverSide": true,
                "ajax": '<?php echo e(route('checkin.data')); ?>',
                dom: 'Bfrtip',
                buttons: [
                    {
                        extend: 'excel',
                        text: 'Export Search Results',
                        className: 'btn btn-default',
                        exportOptions: {
                            columns: 'th:not(:last-child)'
                        }
                    }
                ],
                "columns": [
                    { "data": "id",  'visible': false },
                    { "data": "DT_RowIndex",  orderable: false, searchable: false },
                    { "data": "customer_id" },
                    { "data": "checked_in" },
                    { "data": "checked_out" },
                    { "data": "total_no_rooms" },
                    { "data": "room_no" },
                    { "data": "room_id" },
                    { "data": "total_no_people" },
                    { "data": "initial_payment" },
                    { "data": "actions", orderable: false, searchable: false },
                ],
                order: [ [0, 'desc'] ]
            });

            table.columns().every( function() {
                var that = this;

                $('input', this.footer()).on('keyup change', function() {
                    if (that.search() !== this.value) {
                        that
                            .search(this.value)
                            .draw();
                    }
                });
            });
        });

        function approvedthis(id) {
            var checkin_id = JSON.parse(id);
            $('.checkin_id').val(checkin_id);
            $('.bs-example-modal-center').modal('show');

        }
    </script>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/demoaccessworld/public_html/projects/customermanagement/resources/views/checkin/index.blade.php ENDPATH**/ ?>