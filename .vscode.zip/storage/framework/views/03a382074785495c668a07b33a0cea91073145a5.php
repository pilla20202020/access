<?php $__env->startSection('page-specific-styles'); ?>
    <link href="<?php echo e(asset('css/dropify.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('resources/css/bootstrap-toggle.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <section>
        <div class="section-body">
            <form class="form form-validate floating-label" action="<?php echo e(route('credit.update',$credit->id)); ?>"
                  method="POST" enctype="multipart/form-data" novalidate>
            <?php echo method_field('PUT'); ?>
            <?php echo $__env->make('credit.form', ['header' => 'Edit Credit'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </form>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\customermanagement\resources\views/credit/edit.blade.php ENDPATH**/ ?>