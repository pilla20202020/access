<?php $__env->startSection('page-specific-styles'); ?>
    <link href="<?php echo e(asset('css/dropify.min.css')); ?>" rel="stylesheet">
    <link type="text/css" rel="stylesheet"
        href="<?php echo e(asset('resources/css/theme-default/libs/bootstrap-tagsinput/bootstrap-tagsinput.css?1424887862')); ?>" />
<?php $__env->stopSection(); ?>
<?php echo csrf_field(); ?>
<div class="row">
    <div class="col-sm-9">
        <div class="card">
            <div class="card-underline">
                <div class="card-head">
                    <header class="ml-3 mt-2"><?php echo $header; ?></header>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-sm-12">
                            

                            <div class="form-group ">
                                <label for="name" class="col-form-label pt-0">Role</label>
                                <div class="">
                                    <input class="form-control" type="text" required name="name"
                                        value="<?php echo e(old('name', isset($role->name) ? $role->name : '')); ?>"
                                        placeholder="Enter Your Name">
                                </div>
                            </div>

                        </div>
                    </div>

                    




                    <?php $__currentLoopData = $groupPermissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="row">
                            <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $title => $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-xs-6 col-sm-4 col-md-4">
                                    <div class="form-group form-check">
                                        <input type="checkbox" class="form-check-input"
                                            data-checkbox-group="<?php echo e(Str::slug($title)); ?>" data-role="selectall">
                                        <label class="form-check-label h5 font-weight-bold text-danger" for="permission"><?php echo e(ucfirst($title)); ?></label>

                                    </div>
                                    <?php $__currentLoopData = $group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="form-group form-check">

                                            <input type="checkbox" class="form-check-input"
                                                name="permissions[<?php echo e($permission->name); ?>]" value="<?php echo e($permission->id); ?>"
                                                <?php echo e(isset($role) &&$role->permissions()->whereName($permission->name)->first()? 'checked': ''); ?>

                                                data-checkbox-group="<?php echo e(Str::slug($title)); ?>" data-role="select">
                                            <label class="form-check-label"
                                                for="<?php echo e($permission->name); ?>"><?php echo e($permission->name); ?></label>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card">
            <div class="card-body">
                <div class="row mt-2 justify-content-center">
                    <div class="form-group">
                        <div>
                            <a class="btn btn-light waves-effect ml-1" href="<?php echo e(route('role.index')); ?>">
                                <i class="md md-arrow-back"></i>
                                Back
                            </a>
                            <input type="submit" name="pageSubmit" class="btn btn-danger waves-effect waves-light"
                                value="Submit">
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>


<?php $__env->startSection('page-specific-scripts'); ?>
    <script src="<?php echo e(asset('resources/js/ckeditor/ckeditor.js')); ?>"></script>
    <script src="<?php echo e(asset('js/dropify.min.js')); ?>"></script>
    <script src="<?php echo e(asset('resources/js/libs/bootstrap-tagsinput/bootstrap-tagsinput.min.js')); ?>"></script>
    <script src="<?php echo e(asset('resources/js/libs/jquery-validation/dist/jquery.validate.min.js')); ?>"></script>
    <script src="<?php echo e(asset('resources/js/libs/jquery-validation/dist/additional-methods.min.js')); ?>"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            $('.dropify').dropify();

            $("[data-role=selectall]").change(function() {
                var $thisgroup = $("[data-checkbox-group=" + $(this).data('checkbox-group') +
                    "][data-role=select]");
                if (this.checked) {
                    $thisgroup.each(function() {
                        this.checked = true;
                    })
                } else {
                    $thisgroup.each(function() {
                        this.checked = false;
                    })
                }
            });

            $("[data-checkbox-group]").change(function() {
                var $thisgroup = $("[data-checkbox-group=" + $(this).data('checkbox-group') +
                    "][data-role=select]");
                var $thisselectall = $("[data-checkbox-group=" + $(this).data('checkbox-group') +
                    "][data-role=selectall]");
                if ($(this).is(":checked")) {
                    var isAllChecked = 0;
                    $thisgroup.each(function() {
                        if (!this.checked)
                            isAllChecked = 1;
                    });
                    if (isAllChecked == 0) {
                        $thisselectall.prop("checked", true);
                    }
                } else {
                    $thisselectall.prop("checked", false);
                }
            });

            $('.card-body').on('click', function(e) {
                $('[data-toggle="popover"]').each(function() {
                    if (!$(this).is(e.target) && $(this).has(e.target).length === 0 && $('.popover')
                        .has(e.target).length === 0) {
                        $(this).popover('hide');
                    }
                });
            });

            $("[data-checkbox-group][data-role=select]").trigger('change');
        });
    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH /home/demoaccessworld/public_html/projects/customermanagement/resources/views/role/form.blade.php ENDPATH**/ ?>