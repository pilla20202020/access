<?php $__env->startSection('title', 'Add a New Room Type'); ?>

<?php $__env->startSection('content'); ?>
    <section>
        <div class="section-body">
            <form class="form form-validate floating-label" action="<?php echo e(route('room.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo $__env->make('roomtype.form',['header' => 'Add new Room Type'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </form>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/demoaccessworld/public_html/projects/customermanagement/resources/views/roomtype/create.blade.php ENDPATH**/ ?>