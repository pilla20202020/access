
<?php if(!empty($followup->registration($followup->id))): ?>

<tr>
    <td><?php echo e(++$key); ?></td>
    <td><?php echo e($followup->registration($followup->id)->name); ?></td>
    <td><?php echo e($followup->registration($followup->id)->email); ?></td>
    <td><?php echo e($followup->registration($followup->id)->phone); ?></td>
    <td><?php echo e($followup->next_schedule); ?></td>
    <td><?php echo e(Str::limit($followup->follow_up_by, 47)); ?></td>
    <td><?php echo e(Str::limit($followup->remarks, 47)); ?></td>

    <td >
        <a href="<?php echo e(route('followup.show', $followup->id)); ?>" class="btn btn-flat btn-primary btn-sm" title="edit">
            <i class="fa fa-eye"></i>
        </a>
        <a href="#">
            <button type="button" class="btn btn-icon-toggle" onclick="deleteThis(this); return false;" link="<?php echo e(route('followup.destroy', $followup->id)); ?>">
                <i class="far fa-trash-alt"></i>
            </button>
        </a>


    </td>
</tr>
<?php endif; ?>


<?php /**PATH C:\xampp\htdocs\bibhuti - access\resources\views/followup/partials/table.blade.php ENDPATH**/ ?>