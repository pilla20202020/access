<?php $__env->startSection('title', 'Followup'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="d-flex">
                <header class="text-capitalize pt-1">Follow Ups</header>
                <div class="form-group ml-auto">
                    <div>
                        <a class="btn btn-light waves-effect ml-1" href="<?php echo e(route('followup.index')); ?>">
                            <i class="md md-arrow-back"></i>
                            Back
                        </a>
                    </div>
                </div>
            </div>

            <div class="card mt-2 p-4">
                <div class="card-body p-5">
                    <div class="container">
                        <h4>Student Detail: </h4>
                        <div class="row">
                            <div class="col-md-4">
                                <label>Student Name: <span><?php echo e($followup->registration($followup->id)->name); ?></span></label>
                            </div>

                            <div class="col-md-4">
                                <label>Email: <span><?php echo e($followup->registration($followup->id)->email); ?></span></label>
                            </div>

                            <div class="col-md-4">
                                <label>Phone: <span><?php echo e($followup->registration($followup->id)->phone); ?></span></label>
                            </div>


                        </div>
                        <hr>
                        <h4>Follow Up Details: </h4>
                        <div class="row">
                            <div class="col-md-4">
                                <label>Folllow Up By: <span><?php echo e($followup->follow_up_by); ?></span></label>
                            </div>

                            <div class="col-md-4">
                                <label>Next Schedule: <span><?php echo e($followup->next_schedule); ?></span></label>
                            </div>

                            <div class="col-md-4">
                                <label>Remarks: <span><?php echo e($followup->remarks); ?></span></label>
                            </div>
                        </div>
                        <hr>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <style type="text/css">
        #accordion .card-head {
            cursor: n-resize;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('backend/js/libs/jquery-validation/dist/jquery.validate.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/js/libs/jquery-validation/dist/additional-methods.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/js/libs/jquery-ui/jquery-ui.min.js')); ?>"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            $('#example').DataTable();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bibhuti - access\resources\views/followup/show.blade.php ENDPATH**/ ?>