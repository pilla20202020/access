<tr style="background: <?php if(!empty($registration->leadcategory)): ?> <?php echo e($registration->leadcategory->color_code); ?> <?php endif; ?>">
    <td class="text-center pt-3">
        <div class="custom-checkbox custom-control">
            <input type="checkbox" name="registrationcheckbox" data-checkboxes="mygroup" class="custom-control-input registrationcheckbox" id="<?php echo e($registration->id); ?>" value="<?php echo e($registration->id); ?>">
            <label for="<?php echo e($registration->id); ?>" class="custom-control-label">&nbsp;</label>
        </div>
    </td>
    <td><?php echo e(++$key); ?></td>
    <td><?php echo e(Str::limit($registration->name, 47)); ?></td>
    <td><?php echo e(Str::limit($registration->email, 47)); ?></td>
    <td><?php echo e(Str::limit($registration->phone, 47)); ?></td>
    <td><?php echo e(ucfirst($registration->preffered_location)); ?></td>

    <td >
        <a href="javascript: void(0);"  data-registration_id="<?php echo e($registration->id); ?>"  class="btn btn-flat mdi mdi-pencil btn-edit" title="Edit Registration">
        </a>
        <a href="<?php echo e(route('registration.show', $registration->id)); ?>" class="btn btn-flat btn-primary btn-sm" title="view">
            <i class="fa fa-eye"></i>
        </a>
        <a href="#">
            <button type="button" class="btn btn-icon-toggle" onclick="deleteThis(this); return false;" link="<?php echo e(route('registration.destroy', $registration->id)); ?>">
                <i class="far fa-trash-alt"></i>
            </button>
        </a>

        <a href="javascript: void(0);" data-registration_id="<?php echo e($registration->id); ?>"  class="btn btn-secondary btn-sm addfollowup" title="Add Follow Up">
            Add Follow Up <?php if(!empty($registration->getFollowUpCount($registration->id))): ?> (<?php echo e($registration->getFollowUpCount($registration->id)->count()); ?>) <?php endif; ?>
        </a>

        <a href="javascript: void(0);" data-registration_id="<?php echo e($registration->id); ?>"  class="btn btn-info btn-sm sendsms" title="Add Follow Up">
            Send SMS
        </a>

        <a href="javascript: void(0);" data-registration_id="<?php echo e($registration->id); ?>"  class="btn btn-warning btn-sm btn-leadcategory" title="Add Lead Category">
            Lead Category
        </a>

    </td>
</tr>


<?php /**PATH C:\xampp\htdocs\bibhuti - access\resources\views/registration/partials/table.blade.php ENDPATH**/ ?>