<?php $__env->startSection('page-specific-styles'); ?>
    <link href="<?php echo e(asset('css/dropify.min.css')); ?>" rel="stylesheet">
    <link type="text/css" rel="stylesheet"
          href="<?php echo e(asset('resources/css/theme-default/libs/bootstrap-tagsinput/bootstrap-tagsinput.css?1424887862')); ?>"/>
<?php $__env->stopSection(); ?>
<?php echo csrf_field(); ?>
<div class="row">
    <div class="col-sm-9">
        <div class="card">
            <div class="card-underline">
                <div class="card-head">
                    <header class="ml-3 mt-2"><?php echo $header; ?></header>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label for="districts" class="col-form-label pt-0">Customers <span class="text-danger">*</span></label>
                                    <select
                                        class="select2 tail-select form-control" id=""
                                        name="customer_id" required>
                                        <option value="" selected disabled>Select Customers</option>
                                        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($customer->id); ?>" <?php if(old('customer_id') == $customer->id): ?> selected <?php endif; ?> <?php if(isset($credit) && ($credit->customer_id == $customer->id)): ?> selected <?php endif; ?> >
                                                <?php echo e(ucfirst($customer->first_name .' '.$customer->middle_name.' '.$customer->last_name)); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['customer_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($errors->first('customer_id')); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <div class="form-group ">
                                <label for="name" class="col-form-label pt-0">Price</label>
                                <input type="number" name="price" class="form-control" required  value="<?php echo e(old('price', isset($credit->price) ? $credit->price : '')); ?>"/>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card" >
            <div class="card-body">
                <div class="row mt-2 justify-content-center">
                    <div class="form-group">
                        <div>
                            <a class="btn btn-light waves-effect ml-1" href="<?php echo e(route('room.index')); ?>">
                                <i class="md md-arrow-back"></i>
                                Back
                            </a>
                            <input type="submit" name="pageSubmit" class="btn btn-danger waves-effect waves-light" value="Submit">
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>


<?php $__env->startSection('page-specific-scripts'); ?>
    <script src="<?php echo e(asset('resources/js/libs/bootstrap-tagsinput/bootstrap-tagsinput.min.js')); ?>"></script>
    <script src="<?php echo e(asset('resources/js/libs/jquery-validation/dist/jquery.validate.min.js')); ?>"></script>
    <script src="<?php echo e(asset('resources/js/libs/jquery-validation/dist/additional-methods.min.js')); ?>"></script>
    <script>
        $(document).ready(function() {
            $('.select2').select2({
                containerCssClass: function(e) {
                    return $(e).attr('required') ? 'required' : '';
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\xampp\htdocs\customermanagement\resources\views/credit/form.blade.php ENDPATH**/ ?>