<?php $__env->startSection('page-specific-styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/jquery.dataTables.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/TableTools.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/lightbox.css')); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'Qualification'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="d-flex">
                <header class="text-capitalize pt-1">Qualification</header>
                
                <div class="tools ml-auto">
                    <a class="btn btn-primary ink-reaction btn-sm" href="<?php echo e(route('qualification.create')); ?>">
                        <i class="md md-add"></i>
                        + Add
                    </a>
                </div>
                
            </div>
            <div class="d-flex">
                <?php if(session()->has('message')): ?>
                    <div class="alert alert-success row" id="response_messsage">
                        <?php echo e(session()->get('message')); ?>

                    </div>
                <?php endif; ?>

                <?php if(session()->has('error')): ?>
                    <div class="alert alert-danger" id="response_messsage">
                        <?php echo e(session()->get('error')); ?>

                    </div>
                <?php endif; ?>
            </div>
            <div class="card mt-2 p-4">
                <table id="datatable" class="table table-bordered">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>S.No.</th>
                            <th>Qualification</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-specific-scripts'); ?>
    <script src="<?php echo e(asset('js/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/lightbox.js')); ?>"></script>
    <script>
        $(document).ready(function() {
            setTimeout(() => {
                $('#response_messsage').hide();
            }, 3000);

            $('#datatable').DataTable({
                "processing": true,
                "serverSide": true,
                "ajax": '<?php echo e(route('qualification.data')); ?>',
                // dom: 'Bfrtip',
                // buttons: [
                //     'copy', 'csv', 'excel', 'pdf', 'print',
                //     // exportOptions: {
                //     //     columns: 'th:not(:last-child)'
                //     // }
                // ],
                dom: 'Bfrtip',
                buttons: [{
                    extend: 'excel',
                    text: 'Export Search Results',
                    className: 'btn btn-default',
                    exportOptions: {
                        columns: 'th:not(:last-child)'
                    }
                }],
                "columns": [{
                        "data": "id",
                        'visible': false
                    },
                    {
                        "data": "DT_RowIndex",
                        orderable: false,
                        searchable: false
                    },
                    {
                        "data": "name"
                    },

                    {
                        "data": "actions",
                        orderable: false,
                        searchable: false
                    },
                ],
                order: [
                    [2, 'desc']
                ]
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bibhuti - access\resources\views/qualification/index.blade.php ENDPATH**/ ?>