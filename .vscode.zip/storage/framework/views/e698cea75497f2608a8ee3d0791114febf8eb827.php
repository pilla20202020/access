<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8" />
        <title><?php echo $__env->yieldContent('title'); ?></title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
        <meta content="Themesbrand" name="author" />

        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <!-- App favicon -->
        <link rel="shortcut icon" href="assets/images/favicon.ico">

        
        <link href="<?php echo e(asset('css/MetroJs.min.css')); ?>" id="app-style" rel="stylesheet" type="text/css" />

        <!-- Bootstrap Css -->
        
        <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" id="app-style" rel="stylesheet" type="text/css" />

        <!-- Icons Css -->
        
        <link href="<?php echo e(asset('css/icons.min.css')); ?>" id="app-style" rel="stylesheet" type="text/css" />

        <!-- App Css-->
        
        <link href="<?php echo e(asset('css/app.min.css')); ?>" id="app-style" rel="stylesheet" type="text/css" />

        <!-- Sweet Alert-->
        <link href="<?php echo e(asset('css/sweetalert2.min.css')); ?>" rel="stylesheet" type="text/css" />

        <!-- Select2-->
        <link href="<?php echo e(asset('css/select2.min.css')); ?>" rel="stylesheet" />

        <!-- style-->
        <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet" />
        <link href="<?php echo e(asset('css/frontend.css')); ?>" rel="stylesheet" />

        <link href="<?php echo e(asset('css/dropify.min.css')); ?>" rel="styleshet">

        <!-- Toastr-->
        <link rel="stylesheet" href="<?php echo e(asset('css/toastr.min.css')); ?>">

        <?php echo $__env->yieldContent('page-specific-styles'); ?>

    </head>

<body>


    <?php echo $__env->make('frontend.layouts.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('frontend.layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <a href="#" class="scrollup" style="display: none;"><i class="ion-ios-arrow-up"></i></a>

    <!-- JAVASCRIPT -->
    
    <script src="<?php echo e(asset('js/jquery.min.js')); ?> "></script>


    
    <script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?> "></script>

    
    <script src="<?php echo e(asset('js/metisMenu.min.js')); ?> "></script>

    
    <script src="<?php echo e(asset('js/simplebar.min.js')); ?> "></script>


    
    

    
    

    <!-- Sweet alert init js-->
    <script src="<?php echo e(asset('js/sweetalert2.min.js')); ?>"></script>

    
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>

    
    <script src="<?php echo e(asset('js/select2.min.js')); ?>"></script>

    <script src="<?php echo e(asset('js/scripts.js')); ?>"></script>

    <script src="<?php echo e(asset('js/toastr/toastr.js')); ?>"></script>

    <script src="<?php echo e(asset('js/jquery.repeater.min.js')); ?>"></script>

    <script src="<?php echo e(asset('js/form-repeater.init.js')); ?>"></script>

    

    <script>
        function deleteThis(obj) {
            let data = obj.getAttribute("link");
            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location = data;
                    Swal.fire(
                        'Deleted!',
                        'Your file has been deleted.',
                        'success'
                    )
                } else {
                    Swal.fire(
                        'Cancelled!',
                        'Your file has been Cancelled.',
                        'error'
                    )
                }
            })
        }
    </script>

    <?php echo $__env->yieldContent('page-specific-scripts'); ?>
    <?php echo Toastr::message(); ?>


</body>


</html>
<?php /**PATH C:\xampp\htdocs\bibhuti - access\resources\views/frontend/layouts/app.blade.php ENDPATH**/ ?>