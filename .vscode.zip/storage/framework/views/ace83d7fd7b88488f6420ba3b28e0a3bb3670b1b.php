<?php $__env->startSection('title', 'Registration'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="d-flex">
                <header class="text-capitalize pt-1">Registration Lists</header>
            </div>
            <div class="card mt-2 p-4">
                <div class="card-body p-5">
                    <div class="container">
                        <h4>Student Detail: </h4>
                        <div class="row">
                            <div class="col-md-4">
                                <label>Student Name: <span><?php echo e($registration->name); ?></span></label>
                            </div>

                            <div class="col-md-4">
                                <label>Email: <span><?php echo e($registration->email); ?></span></label>
                            </div>

                            <div class="col-md-4">
                                <label>Phone: <span><?php echo e($registration->phone); ?></span></label>
                            </div>

                            <div class="col-md-4 mt-1">
                                <label>Intrested Country: <span><?php echo e($registration->interested_for_country); ?></span></label>
                            </div>

                            <div class="col-md-4">
                                <label>Intrested Course: <span><?php echo e($registration->interested_course); ?></span></label>
                            </div>

                            <div class="col-md-4">
                                <label>Preffered Location: <span><?php echo e($registration->preffered_location); ?></span></label>
                            </div>
                        </div>
                        <hr>
                        <h4>Address: </h4>
                        <div class="row">
                            <div class="col-md-3">
                                <label>Zone: <span><?php echo e($registration->zone); ?></span></label>
                            </div>

                            <div class="col-md-3">
                                <label>State: <span><?php echo e($registration->state); ?></span></label>
                            </div>

                            <div class="col-md-3">
                                <label>City: <span><?php echo e($registration->city); ?></span></label>
                            </div>

                            <div class="col-md-3">
                                <label>Address: <span><?php echo e($registration->address); ?></span></label>
                            </div>

                            <div class="col-md-3">
                                <label>Nearest landmark: <span><?php echo e($registration->nearest_landmark); ?></span></label>
                            </div>
                        </div>
                        <hr>
                        <h4>SEE Detail: </h4>
                        <div class="row">
                            <div class="col-md-3">
                                <label>SEE Year: <span><?php echo e($registration->see_year); ?></span></label>
                            </div>

                            <div class="col-md-3">
                                <label>SEE Grade: <span><?php echo e($registration->see_grade); ?></span></label>
                            </div>

                            <div class="col-md-3">
                                <label>SEE Stream: <span><?php echo e($registration->see_stream); ?></span></label>
                            </div>

                            <div class="col-md-3">
                                <label>SEE School: <span><?php echo e($registration->see_school); ?></span></label>
                            </div>
                        </div>
                        <hr>

                        <h4>+2 Detail: </h4>
                        <div class="row">
                            <div class="col-md-3">
                                <label>+2 Year: <span><?php echo e($registration->plus2_year); ?></span></label>
                            </div>

                            <div class="col-md-3">
                                <label>+2 Grade: <span><?php echo e($registration->plus2_grade); ?></span></label>
                            </div>

                            <div class="col-md-3">
                                <label>+2 Stream: <span><?php echo e($registration->plus2_stream); ?></span></label>
                            </div>

                            <div class="col-md-3">
                                <label>+2 College: <span><?php echo e($registration->plus2_college); ?></span></label>
                            </div>
                        </div>
                        <hr>

                        <h4>Bachelor Detail: </h4>
                        <div class="row">
                            <div class="col-md-3">
                                <label>Bachelor Year: <span><?php echo e($registration->bachelors_year); ?></span></label>
                            </div>

                            <div class="col-md-3">
                                <label>Bachelor Grade: <span><?php echo e($registration->bachelors_grade); ?></span></label>
                            </div>

                            <div class="col-md-3">
                                <label>Bachelor Stream: <span><?php echo e($registration->bachelors_stream); ?></span></label>
                            </div>

                            <div class="col-md-3">
                                <label>Bachelor College: <span><?php echo e($registration->bachelors_college); ?></span></label>
                            </div>
                        </div>
                        <hr>

                        <h4>Highest Qualification Detail: </h4>
                        <div class="row">
                            <div class="col-md-3">
                                <label>Highest Qualification Year:
                                    <span><?php echo e($registration->highest_qualification); ?></span></label>
                            </div>

                            <div class="col-md-3">
                                <label>Highest Qualification Grade: <span><?php echo e($registration->highest_grade); ?></span></label>
                            </div>

                            <div class="col-md-3">
                                <label>Highest Qualification Stream:
                                    <span><?php echo e($registration->highest_stream); ?></span></label>
                            </div>

                            <div class="col-md-3">
                                <label>Highest Qualification College:
                                    <span><?php echo e($registration->highest_college); ?></span></label>
                            </div>
                        </div>
                        <hr>

                        <h4>Preparation Class Detail: </h4>
                        <div class="row">
                            <div class="col-md-3">
                                <label>Preparation Class Year: <span><?php echo e($registration->preparation_class); ?></span></label>
                            </div>

                            <div class="col-md-3">
                                <label>Preparation Class Score: <span><?php echo e($registration->preparation_score); ?></span></label>
                            </div>

                            <div class="col-md-3">
                                <label>BandScore: <span><?php echo e($registration->preparation_bandscore); ?></span></label>
                            </div>

                            <div class="col-md-3">
                                <label>Date: <span><?php echo e($registration->preparation_date); ?></span></label>
                            </div>

                            <div class="col-md-6">
                                <label>Test Name: <span><?php echo e($registration->test_name); ?></span></label>
                            </div>

                            <div class="col-md-6">
                                <label>Test Score: <span><?php echo e($registration->test_score); ?></span></label>
                            </div>
                        </div>
                        <hr>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <style type="text/css">
        #accordion .card-head {
            cursor: n-resize;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('backend/js/libs/jquery-validation/dist/jquery.validate.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/js/libs/jquery-validation/dist/additional-methods.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/js/libs/jquery-ui/jquery-ui.min.js')); ?>"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            $('#example').DataTable();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bibhuti - access\resources\views/registration/show.blade.php ENDPATH**/ ?>