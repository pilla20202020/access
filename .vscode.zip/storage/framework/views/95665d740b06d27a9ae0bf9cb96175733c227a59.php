<?php $__env->startSection('content'); ?>
    <!-- START SECTION BREADCRUMB -->

<!-- START SECTION 404 -->
<section class="background_bg overlay_bg2 full_screen pt-5"  style="background-image: url(<?php echo e(asset('assets/images/404_bg.jpg')); ?>)">
    <div class="container h-100">
        <div class="row justify-content-center align-content-center h-100">
            <div class="col-md-6 col-sm-8">
                <div class="text-center">
                    <div class="error_txt">404</div>
                    <h4 class="text_danger">oops! Page Not Found!</h4>
                    <h6>The page you were looking for could not be found.</h6>
                    <a href="<?php echo e(route('homepage')); ?>" class="btn btn-outline-black">Back To Home</a>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- END SECTION 404 -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bibhuti - access\resources\views/frontend/errors/404.blade.php ENDPATH**/ ?>