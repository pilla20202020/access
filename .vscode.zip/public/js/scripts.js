$(document).ready(function() {
    $('.js-example-basic-multiple').select2();
});
