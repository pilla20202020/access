<?php

return [

    'work_type' => [
        'Labor' =>'Labor',
        'Masion' => 'Masion',
        'Custodian' => 'Custodian',
        'Packer' => 'Packer',
        'Farm laborer' => 'Farm laborer',
        'Gardener' => 'Gardener',
        'Welder' => 'Welder',
        'Tree climber' => 'Tree climber',
        'Crew foreman' => 'Crew foreman',
        'Carpenter' => 'Carpenter',
        'Plumber' => 'Plumber',
        'Electrician' => 'Electrician',
    ],
    'experience_year' =>[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15]

];
