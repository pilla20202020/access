<?php echo csrf_field(); ?>
<div class="row">
    <div class="col-sm-9">
        <div class="card">
            <div class="card-underline">
                <div class="card-head">
                    <header><?php echo $header; ?></header>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-8">
                            <div class="form-group">
                                <input type="text" name="name" class="form-control" required
                                       value="<?php echo e(old('name', isset($campaign->name) ? $campaign->name : '')); ?>"/>

                                <label for="Name">Name</label>
                                <span id="textarea1-error" class="text-danger"><?php echo e($errors->first('name')); ?></span>
                            </div>
                        </div>
                        <div class="col-md-4" id="imageupload">
                            
                                <label class="text-default-light">Banner Image</label>
                                <?php if(isset($campaign) && $campaign->banner): ?>
                                    <input type="file" name="banner" class="dropify"
                                        data-default-file="<?php echo e(asset($campaign->thumbnail_path)); ?>"/>
                                <?php else: ?>
                                    <input type="file" name="banner" class="dropify"/>
                                <?php endif; ?>
                            </div>


                    </div>
                     
                    <div class="row">

                        <div class="col-md-12">
                            <div class="form-group">
                                <textarea  name="details" class="form-control"><?php echo e(old('details', isset($campaign->details) ? $campaign->details : '')); ?>

                                </textarea>

                                <label for="Name">Details</label>
                                <span id="textarea1-error" class="text-danger"><?php echo e($errors->first('details')); ?></span>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                   
                        <div class="col-md-6">
                            <div class="form-group">
                                <textarea  name="success_message" class="form-control" rows="4"><?php echo e(old('success_message', isset($campaign->success_message) ? $campaign->success_message : '')); ?>

                                </textarea>
                              

                                <label for="Name">Success Message</label>
                                <span id="textarea1-error" class="text-danger" ><?php echo e($errors->first('success_message')); ?></span>
                            </div>
                        </div>
                    
                        <div class="col-md-6">
                            <div class="form-group">
                                <textarea  name="sms_message" class="form-control" rows="4"><?php echo e(old('sms_message', isset($campaign->sms_message) ? $campaign->sms_message : '')); ?>

                                </textarea>
                                

                                <label for="Name">SMS Message</label>
                                <span id="textarea1-error" class="text-danger"><?php echo e($errors->first('sms_message')); ?></span>
                            </div>
                        </div>
                    </div>
                   

                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="date" name="starts" class="form-control" required
                                       value="<?php echo e(old('starts', isset($campaign->starts) ? $campaign->starts : '')); ?>"/>

                                <label for="starts">Starts</label>
                                <span id="textarea1-error" class="text-danger"><?php echo e($errors->first('starts')); ?></span>
                            </div>
                        </div>

                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="date" name="ends" class="form-control" required
                                       value="<?php echo e(old('ends', isset($campaign->ends) ? $campaign->ends : '')); ?>"/>

                                <label for="ends">Ends</label>
                                <span id="textarea1-error" class="text-danger"><?php echo e($errors->first('ends')); ?></span>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group">
                                <strong>Description</strong>
                                <textarea name="description" id=""
                                          class="ckeditor"><?php echo e(old('description',isset($campaign->description)?$campaign->description : '')); ?></textarea>

                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <strong>Coupen Codes</strong>
                                <textarea name="coupon_codes" id="coupon_codes"
                                          class="form-control" rows="4"><?php echo e(old('coupon_codes',isset($campaign->coupon_codes)?$campaign->coupon_codes : '')); ?></textarea>

                            </div>
                        </div>
                   

                        <div class="col-sm-6">
                            <div class="form-group">
                                <strong>OG Tags</strong>
                                <textarea name="ogtags" id="ogtags"
                                          class="form-control" rows="4"><?php echo e(old('ogtags',isset($campaign->ogtags)?$campaign->ogtags : '')); ?></textarea>

                            </div>
                        </div>

                        


                    </div>
                    <div class="row">


                       

                        <div class="col-md-12">
                            <div class="form-group">
                                <textarea  name="keywords" class="form-control" rows="4"><?php echo e(old('keywords', isset($campaign->keywords) ? $campaign->keywords : '')); ?>

                                </textarea>
                                

                                <label for="Name">Keywords - Use , (comma) for multiple</label>
                                <span id="textarea1-error" class="text-danger"><?php echo e($errors->first('keywords')); ?></span>
                            </div>
                        </div>
                    </div>

                    
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="" data-spy="affix" data-offset-top="50">
            <div class="panel-group" id="accordion1">
                <div class="card panel expanded">
                    <div class="card-head" data-toggle="collapse" data-parent="#accordion1" data-target="#accordion1-1">
                        <header>Publish</header>
                        <div class="tools">
                            <a class="btn btn-icon-toggle"><i class="fa fa-angle-down"></i></a>
                        </div>
                    </div>
                    <div id="accordion1-1" class="collapse in">

                        <div class="card-head">
                            <div class="side-label">
                                <div class="label-head">
                                    <span>Status</span>
                                </div>
                                <div class="label-body">
                                    <input type="checkbox" id="switch_demo_1" name="status"
                                           <?php echo e(old('status', isset($campaign->status) ? $campaign->status : '')=='active' ? 'checked':''); ?> data-switchery/>
                                </div>
                            </div>
                            
                        </div>

                        <div class="card-actionbar">
                            <div class="card-actionbar-row">
                                <a class="btn btn-default btn-ink" href="<?php echo e(route('campaign.index')); ?>">
                                    <i class="md md-arrow-back"></i>
                                    Back
                                </a>
                                <input type="submit" name="pageSubmit" class="btn btn-info ink-reaction" value="Save">
                            </div>
                        </div>
                    </div>
                </div>
                <!--end .panel --><!--end .panel --><!--end .panel --><!--end .panel -->

                <!--end .panel --><!--end .panel --><!--end .panel --><!--end .panel -->
            </div><!--end .panel-group -->
        </div>
    </div>
</div>
<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('resources/js/libs/jquery-validation/dist/jquery.validate.min.js')); ?>"></script>
    <script src="<?php echo e(asset('resources/js/libs/jquery-validation/dist/additional-methods.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php /**PATH D:\xampp\htdocs\bishal\access\resources\views/backend/campaign/partials/form.blade.php ENDPATH**/ ?>