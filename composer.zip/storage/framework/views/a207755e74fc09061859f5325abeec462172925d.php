<footer class="footer">
    <div class="menubar-foot-panel">
						<small class="no-linebreak hidden-folded">
							<span class="opacity-75">Copyright &copy; 2021</span> <strong>Project</strong>
						</small>
	</div>
</footer>
<?php /**PATH D:\xampp\htdocs\bishal\access\resources\views/backend/layouts/admin/footer.blade.php ENDPATH**/ ?>