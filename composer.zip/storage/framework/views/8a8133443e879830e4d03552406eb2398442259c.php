<!-- END SECTION CALL TO ACTION -->

<!-- END SECTION CALL TO ACTION -->
<!-- START FOOTER -->

<!-- END FOOTER -->
<?php /**PATH D:\xampp\htdocs\bishal\access\resources\views/frontend/layouts/partials/footer.blade.php ENDPATH**/ ?>