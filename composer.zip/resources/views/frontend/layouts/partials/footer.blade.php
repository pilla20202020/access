<!-- END SECTION CALL TO ACTION -->
{{-- <section class="bg_default small_pt small_pb">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-8">
                <div class="text_white cta_section">
                    <div class="medium_divider d-block d-md-none"></div>
                    <div class="heading_s1 heading_light">
                        <h2>project!</h2>
                    </div>
                    <p>If you are going to use a passage of embarrassing hidden in the middle of text</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="text-md-right">
                    <a href="#" class="btn btn-outline-white rounded-0">Get Started</a>
                </div>
                <div class="medium_divider d-block d-md-none"></div>
            </div>
        </div>
    </div>
</section> --}}
<!-- END SECTION CALL TO ACTION -->
<!-- START FOOTER -->
{{-- <footer class="bg_blue_dark footer_dark">
    <div class="top_footer">
        <div class="container">

        </div>
    </div>

</footer> --}}
<!-- END FOOTER -->
