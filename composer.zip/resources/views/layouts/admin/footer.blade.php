<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                2018 - <script>document.write(new Date().getFullYear())</script> © New Project
            </div>
        </div>
    </div>
</footer>




